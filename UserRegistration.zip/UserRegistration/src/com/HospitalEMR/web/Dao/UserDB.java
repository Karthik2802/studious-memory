package com.HospitalEMR.web.Dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.HospitalEMR.User.web.Model.UserBean;

import Connection.InitCon;

public class UserDB {


/*	
public static UserBean selectuserData(int UserID) throws SQLException
{
	
	 InitCon it = new InitCon();
	 Connection con = it.InitConnection();
	 
	UserBean ub = null;
	 CallableStatement st;
	 ResultSet rs = null;
	 String DbFlage;
	
	try
	{
		if(UserID ==0)
		{
			ub = new UserBean();
			
			ub.setUserID(0);
			
			ub.setFirstname("");
			ub.setLastname("");
			ub.setAccessrole("");
			ub.setUsername("");
			ub.setPassword("");
			ub.setConfirmpassword("");
			ub.setEmailid("");
			ub.setId_status("");				
			ub.setUpdateFlage("NO");
			
			
			
		}
		else
		{
			DbFlage="select_user_data";
			st=con.prepareCall("{call users(?,?,?,?,?,?,?,?,?,?,?,?)}");
			st.setString(1,null);
			st.setString(2, null);
			st.setString(3,null);
			st.setString(4, null);
			st.setString(5, null);
			st.setString(6, null);
			st.setString(7, null);
			st.setString(8, null);
			st.setString(9, null);
			st.setString(10, null);
			st.setInt(11, UserID );
			st.setString(12, DbFlage);
			rs = st.executeQuery();
			
			 
			 boolean record = rs.next();
			 if(record)
			 {
				 
				 ub = new UserBean();
					
					ub.setUserID(UserID);
					
					ub.setFirstname(rs.getString(2));
					ub.setLastname(rs.getString(3));
					ub.setAccessrole(rs.getString(4));
					ub.setUsername(rs.getString(5));
					ub.setPassword(rs.getString(6));
					ub.setConfirmpassword(rs.getString(7));
					ub.setEmailid(rs.getString(8));
					ub.setId_status(rs.getString(11));
					ub.setAccesrole_description(rs.getString(13));
					ub.setUpdateFlage("YES");
				 
			 }
			 
			 con.close();
		}
		
	}catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	return ub;
	
	

}*/

public boolean check(String userName) throws SQLException
{
	/* response.setContentType("text/html");  
	 PrintWriter out = response.getWriter(); */ 
	InitCon it = new InitCon();
	Connection con = it.InitConnection();
	CallableStatement st;
	String DbFlage;
	ResultSet rs=null;
	String check=null;
	String usernamedb;
	try
	{
		//DbFlage="Login";
		DbFlage="check";
		st=con.prepareCall("{call users(?,?,?,?,?,?,?,?,?,?,?,?)}");
		st.setString(1, null);
		st.setString(2, null);
		st.setString(3, null);
		st.setString(4, userName);
		st.setString(5, null);
		st.setString(6, null);
		st.setString(7, null);
		st.setString(8, null);
		st.setString(9, null);
		st.setString(10, null);
		st.setString(11, null);
		st.setString(12, DbFlage);
		rs = st.executeQuery();
	

	
		 int count=0;
		while(rs.next())
		{		
			usernamedb=rs.getString(1);
			
			count++;
		}	
			
		if(count>0)
		{
			
		     /*msg="username unavailable";
		     response.setContentType("application/plain");
		     response.getWriter().write(msg);*/
  		    System.out.println("username already register");
  		   
  		    return true;
		}
		
			
		else
		{
			 /*msg="username available";
			 response.setContentType("application/plain");
		     response.getWriter().write(msg);*/
			System.out.println("username available");
		}

	
	         
		 
	
	 con.close ();
    }
		
	
	catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	
	
	return false;

}


public static int SaveUser(UserBean um) throws SQLException
{
	int status=0;
	InitCon it = new InitCon();
	Connection con = it.InitConnection();
	CallableStatement st;
	String DbFlage;
	try
	{
		DbFlage="SaveUserDeatails";
		st=con.prepareCall("{call users(?,?,?,?,?,?,?,?,?,?,?,?)}");
		st.setString(1, um.getFirstname());
		st.setString(2, um.getLastname());
		st.setString(3, um.getAccessrole());
		st.setString(4, um.getUsername());
		st.setString(5, um.getPassword());
		st.setString(6, um.getConfirmpassword());
		st.setString(7, um.getEmailid());
		st.setString(8, um.getLastcreatedname());
		st.setString(9, um.getLastcreatedtime());
		st.setString(10, um.getId_status());
		st.setInt(11, um.getUserID());
		st.setString(12, DbFlage);
		status=st.executeUpdate();
		con.close();
		
	}
	catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	
	return status;
	
}

}