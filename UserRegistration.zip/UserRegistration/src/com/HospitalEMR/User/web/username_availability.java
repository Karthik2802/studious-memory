package com.HospitalEMR.User.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Connection.InitCon;



/**
 * Servlet implementation class username_availability
 */
@WebServlet("/username_availability")
public class username_availability extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public username_availability() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		
		 response.setContentType("text/html");  
		 PrintWriter out = response.getWriter();  
		
		//ArrayList<String> al = new ArrayList();
		ResultSet rs;
		PreparedStatement ps;
		CallableStatement st; 
		/*InitCon it = new InitCon();
		Connection con = it.InitConnection();*/
		String DBFlage;
		
		
		String username=request.getParameter("username");
		
		
		String msg;
		String  usernamedb;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bcc_emr","bccappuser","1@Bccappuser");  
	
			DBFlage="check";
		    st=con.prepareCall("{call users(?,?,?,?,?,?,?,?,?,?,?,?)}");			
			//ps=con.prepareStatement("select username from user where username=?");
			
			st.setString(1,null);
			st.setString(2,null);
			st.setString(3,null );
			st.setString(4,username );
			st.setString(5,null );
			st.setString(6,null );
			st.setString(7,null );
			st.setString(8,null);
			st.setString(9,null);
			st.setString(10, null);
			st.setString(11, null);
			st.setString(12, DBFlage);
			
			
			rs=st.executeQuery();	
		
			
			
			int count=0;
			while(rs.next())
			 {

				usernamedb=(rs.getString(1));
				System.out.println(usernamedb);
				count++;
			 }
			if(count>0)
			{
				
			     msg="username unavailable";
			     response.setContentType("application/plain");
			     response.getWriter().write(msg);
     		    System.out.println("username already register");
     		    
     		    return ;
			}
			
				
			else
			{
				 msg="username available";
				 response.setContentType("application/plain");
			     response.getWriter().write(msg);
				System.out.println("username available");
			}
	
		
		         
			 
		
		 con.close ();
	}
	catch (Exception e)
	{
	  
		e.printStackTrace();// TODO: handle exception
	}
		
	}
	
		
	

}
