package com.HospitalEMR.User.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.HospitalEMR.web.Dao.UserDB;
import com.HospitalEMR.User.web.Model.UserBean;

/*import com.sun.tools.javac.comp.Check;*/

/**
 * Servlet implementation class UserMain
 */
@WebServlet("/UserMain")
public class UserMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserMain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		int status=0;
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String U_id = request.getParameter("userID");
		int UserID =Integer.parseInt(U_id);
		
	//	String updateFlage = request.getParameter("updateFlage");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String accessrole = request.getParameter("accessrole");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String confirmpassword = request.getParameter("confirmpassword");
		String emailid =  request.getParameter("emailid");
		String id_status = request.getParameter("id_status");
		String lastcreatedname = request.getParameter("lastcreatedname");
		String lastcreatedtime = request.getParameter("lastcreatedtime");
		
		/*bcrypt b=new bcrypt();
		String password1=bcrypt.hashPassword(password);
	
		bcrypt b1=new bcrypt();
		String confirmpassword1=bcrypt.hashPassword(confirmpassword);*/
		
		
		UserBean ub = new UserBean();
		
		ub.setUserID(UserID);
		ub.setFirstname(firstname);
		ub.setLastname(lastname);
		ub.setAccessrole(accessrole);
		ub.setUsername(username);
		
		/*ub.setPassword(bcrypt.hashPassword(password));                           //calling hashing method from bcrypt.java file		
		ub.setConfirmpassword(bcrypt.hashPassword(confirmpassword)); */ 
		ub.setPassword(password);  
		ub.setConfirmpassword(confirmpassword);      //calling checkpassword method from bcrypt.java file
		
		ub.setEmailid(emailid);
		ub.setLastcreatedname(lastcreatedname);
		ub.setLastcreatedtime(lastcreatedtime);
		
		ub.setId_status(id_status);
	//	ub.setUpdateFlage(updateFlage);
		
		
		UserDB udb = new UserDB();
		
		try
		{
			
			status=udb.SaveUser(ub);
			/*if(ub.getUpdateFlage().equals("NO"))
			{
				status=udb.SaveUser(ub);
			}*/
			/*else
			{
				status=udb.UpdateUser(ub);
				status=2;
			}
			*/
			

			 if(status==1)
				{
					pw.println("<script type=\"text/javascript\">");
					pw.println("alert(' USER CREATED Successfully');");
				
					pw.println("location='user_registration.jsp';");
					pw.println("</script>");
				}
			/* else if (status==2)
			 {
				 pw.println("<script type=\"text/javascript\">");
					pw.println("alert(' USER Updated Successfully');");
					pw.println("location='User.jsp';");
					pw.println("</script>");
			 }*/
			 else				 
			 {
				 pw.println("<script type=\"text/javascript\">");
					pw.println("alert(' SORRY...! Not CREATED.. Try Again Later');");
					pw.println("location='user_registration.jsp';");
					pw.println("</script>");
				 
			 }
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
			
	}

}
