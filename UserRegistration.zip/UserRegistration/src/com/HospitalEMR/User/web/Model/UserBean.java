package com.HospitalEMR.User.web.Model;

public class UserBean
{
	private int UserID;
	private String firstname,lastname,accessrole,username,password,confirmpassword,emailid,lastcreatedname,lastcreatedtime,id_status,updateFlage,Accesrole_description ;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getAccessrole() {
		return accessrole;
	}

	public void setAccessrole(String accessrole) {
		this.accessrole = accessrole;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getLastcreatedname() {
		return lastcreatedname;
	}

	public void setLastcreatedname(String lastcreatedname) {
		this.lastcreatedname = lastcreatedname;
	}

	public String getLastcreatedtime() {
		return lastcreatedtime;
	}

	public void setLastcreatedtime(String lastcreatedtime) {
		this.lastcreatedtime = lastcreatedtime;
	}

	public String getId_status() {
		return id_status;
	}

	public void setId_status(String id_status) {
		this.id_status = id_status;
	}

	public int getUserID() {
		return UserID;
	}

	public void setUserID(int userID) {
		UserID = userID;
	}

	public String getUpdateFlage() {
		return updateFlage;
	}

	public void setUpdateFlage(String updateFlage) {
		this.updateFlage = updateFlage;
	}

	public String getAccesrole_description() {
		return Accesrole_description;
	}

	public void setAccesrole_description(String accesrole_description) {
		Accesrole_description = accesrole_description;
	}
	
	
	
	
	
	

	
	
}
