package com.HospitalEMR.User.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.HospitalEMR.User.web.Dao.UserDB;
import com.HospitalEMR.User.web.Model.UserBean;

import Connection.InitCon;

/**
 * Servlet implementation class reset
 */
@WebServlet("/reset")
public class reset extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public reset() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	

		int status=0;
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String userID=request.getParameter("userID");
		int UserID =Integer.parseInt(userID);
		
		String accessrole = request.getParameter("accessrole");

		String username = request.getParameter("username");
		String confirmpassword = request.getParameter("confirmpassword");
		String lastcreatedname = request.getParameter("lastcreatedname");
		String lastcreatedtime = request.getParameter("lastcreatedtime");
	//	String password = request.getParameter("password");
		String newpassword=request.getParameter("newpassword");
		
		
        UserBean ub = new UserBean();
		
		
		ub.setAccessrole(accessrole);
		ub.setUsername(username);
		ub.setPassword(newpassword);                         // want o call bcrypt algorithm
		ub.setConfirmpassword(confirmpassword);
		ub.setUserID(UserID);
		ub.setLastcreatedtime(lastcreatedtime);
		ub.setLastcreatedname(lastcreatedname);
		
//		UserDB udb = new UserDB();
		try
		{

			/*if(accessrole=="1")
			{*/
				
//				status=udb.change(ub);
				status=2;
			/*}*/
			
			 if (status==2)
			 {
				 pw.println("<script type=\"text/javascript\">");
					pw.println("alert(' USER Updated Successfully');");
					pw.println("location='Login.jsp';");
					pw.println("</script>");
			 }
			else{
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert(' SORRY...! Not CREATED.. Try Again Later');");
				pw.println("location='addUser.jsp';");
				pw.println("</script>");
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	
			
	}
}


